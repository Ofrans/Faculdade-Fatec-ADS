// Função para gerar um vetor aleatório de tamanho n
function gerarVetorAleatorio(tamanho) {
  let vetor = [];
  for (let i = 0; i < tamanho; i++) {
    vetor.push(Math.floor(Math.random() * tamanho));
  }
  return vetor;
}

// Função para gerar um vetor ordenado de tamanho n
function gerarVetorOrdenado(tamanho) {
  let vetor = [];
  for (let i = 0; i < tamanho; i++) {
    vetor.push(i);
  }
  return vetor;
}

// Função para gerar um vetor invertido de tamanho n
function gerarVetorInvertido(tamanho) {
  const vetor = [];
  for (let i = tamanho - 1; i >= 0; i--) {
    vetor.push(i);
  }
  return vetor;
}

// Implementação do Bubble Sort
function bubbleSort(vetor) {
  let n = vetor.length;
  for (let i = 0; i < n - 1; i++) {
    for (let j = 0; j < n - i - 1; j++) {
      if (vetor[j] > vetor[j + 1]) {
        // Troca os elementos
        let temp = vetor[j];
        vetor[j] = vetor[j + 1];
        vetor[j + 1] = temp;
      }
    }
  }
  return vetor;
}

// Implementação do Selection Sort
function selectionSort(vetor) {
  let n = vetor.length;
  for (let i = 0; i < n - 1; i++) {
    let indiceMinimo = i;
    for (let j = i + 1; j < n; j++) {
      if (vetor[j] < vetor[indiceMinimo]) {
        indiceMinimo = j;
      }
    }
    // Troca os elementos
    const temp = vetor[i];
    vetor[i] = vetor[indiceMinimo];
    vetor[indiceMinimo] = temp;
  }
  return vetor;
}

// Implementação do Insertion Sort
function insertionSort(vetor) {
  const n = vetor.length;
  for (let i = 1; i < n; i++) {
    const atual = vetor[i];
    let j = i - 1;
    while (j >= 0 && vetor[j] > atual) {
      vetor[j + 1] = vetor[j];
      j--;
    }
    vetor[j + 1] = atual;
  }
  return vetor;
}

// Função para medir o tempo de execução de uma função de ordenação
function medirTempo(funcaoOrdenacao, vetor) {
  const tempoInicial = new Date().getTime();
  funcaoOrdenacao(vetor);
  const tempoFinal = new Date().getTime();
  return tempoFinal - tempoInicial;
}

// Implementação do Quicksort
function quicksort(vetor) {
  if (vetor.length <= 1) {
    return vetor; // Vetor de tamanho 0 ou 1 já está ordenado
  }

  const pivot = vetor[Math.floor(Math.random() * vetor.length)]; // Escolhe um elemento aleatório como pivô
  const menores = [];
  const iguais = [];
  const maiores = [];

  for (const elemento of vetor) {
    if (elemento < pivot) {
      menores.push(elemento);
    } else if (elemento === pivot) {
      iguais.push(elemento);
    } else {
      maiores.push(elemento);
    }
  }

  return [...quicksort(menores), ...iguais, ...quicksort(maiores)];
}

// Resto do seu código


function main(){
  // Tamanhos dos vetores
  const tamanhoVetor = 100;
  const tamanhoVetor2 = 1000;
  const tamanhoVetor3 = 10000;
  const tamanhoVetor4 = 100000;
  
  // Geração dos vetores
  const vetorAleatorio = gerarVetorAleatorio(tamanhoVetor);
  const vetorOrdenado = gerarVetorOrdenado(tamanhoVetor);
  const vetorInvertido = gerarVetorInvertido(tamanhoVetor);
  
  const vetorAleatorio2 = gerarVetorAleatorio(tamanhoVetor2);
  const vetorOrdenado2 = gerarVetorOrdenado(tamanhoVetor2);
  const vetorInvertido2 = gerarVetorInvertido(tamanhoVetor2);
  
  const vetorAleatorio3 = gerarVetorAleatorio(tamanhoVetor3);
  const vetorOrdenado3 = gerarVetorOrdenado(tamanhoVetor3);
  const vetorInvertido3 = gerarVetorInvertido(tamanhoVetor3);
  
  const vetorAleatorio4 = gerarVetorAleatorio(tamanhoVetor4);
  const vetorOrdenado4 = gerarVetorOrdenado(tamanhoVetor4);
  const vetorInvertido4 = gerarVetorInvertido(tamanhoVetor4);
  
  // Medição de tempo e execução das ordenações

  // Com 100
  const tempoBubbleSortAleatorio = medirTempo(bubbleSort, vetorAleatorio.slice());
  const tempoSelectionSortAleatorio = medirTempo(selectionSort, vetorAleatorio.slice());
  const tempoInsertionSortAleatorio = medirTempo(insertionSort, vetorAleatorio.slice());
  const tempoQuicksortAleatorio = medirTempo(quicksort, vetorAleatorio.slice());

  const tempoBubbleSortOrdenado = medirTempo(bubbleSort, vetorOrdenado.slice());
  const tempoSelectionSortOrdenado = medirTempo(selectionSort, vetorOrdenado.slice());
  const tempoInsertionSortOrdenado = medirTempo(insertionSort, vetorOrdenado.slice());
  const tempoQuicksortOrdenado = medirTempo(quicksort, vetorOrdenado.slice());

  const tempoBubbleSortInvertido = medirTempo(bubbleSort, vetorInvertido.slice());
  const tempoSelectionSortInvertido = medirTempo(selectionSort, vetorInvertido.slice());
  const tempoInsertionSortInvertido = medirTempo(insertionSort, vetorInvertido.slice());
  const tempoQuicksortInvertido = medirTempo(quicksort, vetorInvertido.slice());
  
  // Com 1000
  const tempoBubbleSortAleatorio2 = medirTempo(bubbleSort, vetorAleatorio2.slice());
  const tempoSelectionSortAleatorio2 = medirTempo(selectionSort, vetorAleatorio2.slice());
  const tempoInsertionSortAleatorio2 = medirTempo(insertionSort, vetorAleatorio2.slice());
  const tempoQuicksortAleatorio2 = medirTempo(quicksort, vetorAleatorio2.slice());

  const tempoBubbleSortOrdenado2 = medirTempo(bubbleSort, vetorOrdenado2.slice());
  const tempoSelectionSortOrdenado2 = medirTempo(selectionSort, vetorOrdenado2.slice());
  const tempoInsertionSortOrdenado2 = medirTempo(insertionSort, vetorOrdenado2.slice());
  const tempoQuicksortOrdenado2 = medirTempo(quicksort, vetorOrdenado2.slice());

  const tempoBubbleSortInvertido2 = medirTempo(bubbleSort, vetorInvertido2.slice());
  const tempoSelectionSortInvertido2 = medirTempo(selectionSort, vetorInvertido2.slice());
  const tempoInsertionSortInvertido2 = medirTempo(insertionSort, vetorInvertido2.slice());
  const tempoQuicksortInvertido2 = medirTempo(quicksort, vetorInvertido2.slice());
  
  // Com 10000
  const tempoBubbleSortAleatorio3 = medirTempo(bubbleSort, vetorAleatorio3.slice());
  const tempoSelectionSortAleatorio3 = medirTempo(selectionSort, vetorAleatorio3.slice());
  const tempoInsertionSortAleatorio3 = medirTempo(insertionSort, vetorAleatorio3.slice());
  const tempoQuicksortAleatorio3 = medirTempo(quicksort, vetorAleatorio3.slice());

  const tempoBubbleSortOrdenado3 = medirTempo(bubbleSort, vetorOrdenado3.slice());
  const tempoSelectionSortOrdenado3 = medirTempo(selectionSort, vetorOrdenado3.slice());
  const tempoInsertionSortOrdenado3 = medirTempo(insertionSort, vetorOrdenado3.slice());
  const tempoQuicksortOrdenado3 = medirTempo(quicksort, vetorOrdenado3.slice());

  const tempoBubbleSortInvertido3 = medirTempo(bubbleSort, vetorInvertido3.slice());
  const tempoSelectionSortInvertido3 = medirTempo(selectionSort, vetorInvertido3.slice());
  const tempoInsertionSortInvertido3 = medirTempo(insertionSort, vetorInvertido3.slice());
  const tempoQuicksortInvertido3 = medirTempo(quicksort, vetorInvertido3.slice());
  
  // Com 10000
  const tempoBubbleSortAleatorio4 = medirTempo(bubbleSort, vetorAleatorio4.slice());
  const tempoSelectionSortAleatorio4 = medirTempo(selectionSort, vetorAleatorio4.slice());
  const tempoInsertionSortAleatorio4 = medirTempo(insertionSort, vetorAleatorio4.slice());
  const tempoQuicksortAleatorio4 = medirTempo(quicksort, vetorAleatorio4.slice());

  const tempoBubbleSortOrdenado4 = medirTempo(bubbleSort, vetorOrdenado4.slice());
  const tempoSelectionSortOrdenado4 = medirTempo(selectionSort, vetorOrdenado4.slice());
  const tempoInsertionSortOrdenado4 = medirTempo(insertionSort, vetorOrdenado4.slice());
  const tempoQuicksortOrdenado4 = medirTempo(quicksort, vetorOrdenado4.slice());

  const tempoBubbleSortInvertido4 = medirTempo(bubbleSort, vetorInvertido4.slice());
  const tempoSelectionSortInvertido4 = medirTempo(selectionSort, vetorInvertido4.slice());
  const tempoInsertionSortInvertido4 = medirTempo(insertionSort, vetorInvertido4.slice());
  const tempoQuicksortInvertido4 = medirTempo(quicksort, vetorInvertido4.slice());

  // Resultados

  // Com 100
  console.log("Vetor de 100")
  // Vetor Aleatório
  console.log("\nVetor Aleatório:");
  console.log("Bubble Sort:", tempoBubbleSortAleatorio, "ms");
  console.log("Seleção direta:", tempoSelectionSortAleatorio, "ms");
  console.log("Inserção direta:", tempoInsertionSortAleatorio, "ms");
  console.log("Quicksort:", tempoQuicksortAleatorio, "ms");
  // Vetor Ordenado
  console.log("\nVetor Ordenado:");
  console.log("Bubble Sort:", tempoBubbleSortOrdenado, "ms");
  console.log("Seleção Direta:", tempoSelectionSortOrdenado, "ms");
  console.log("Inserção Direta:", tempoInsertionSortOrdenado, "ms");
  console.log("Quicksort:", tempoQuicksortOrdenado, "ms");
  // Vetor Invertido
  console.log("\nVetor Invertido:");
  console.log("Bubble Sort:", tempoBubbleSortInvertido, "ms");
  console.log("Seleção Direta:", tempoSelectionSortInvertido, "ms");
  console.log("Inserção direta:", tempoInsertionSortInvertido, "ms");
  console.log("Quicksort:", tempoQuicksortInvertido, "ms");
  
  // Com 1000
  console.log("\nVetor de 1000")

  // Vetor Aleatório
  console.log("\nVetor Aleatório:");
  console.log("Bubble Sort:", tempoBubbleSortAleatorio2, "ms");
  console.log("Seleção direta:", tempoSelectionSortAleatorio2, "ms");
  console.log("Inserção direta:", tempoInsertionSortAleatorio2, "ms");
  console.log("Quicksort:", tempoQuicksortAleatorio2, "ms");

  // Vetor Ordenado
  console.log("\nVetor Ordenado:");
  console.log("Bubble Sort:", tempoBubbleSortOrdenado2, "ms");
  console.log("Seleção Direta:", tempoSelectionSortOrdenado2, "ms");
  console.log("Inserção Direta:", tempoInsertionSortOrdenado2, "ms");
  console.log("Quicksort:", tempoQuicksortOrdenado2, "ms");

  // Vetor Invertido
  console.log("\nVetor Invertido:");
  console.log("Bubble Sort:", tempoBubbleSortInvertido2, "ms");
  console.log("Seleção Direta:", tempoSelectionSortInvertido2, "ms");
  console.log("Inserção direta:", tempoInsertionSortInvertido2, "ms");
  console.log("Quicksort:", tempoQuicksortInvertido2, "ms");
  
  // Com 10000
  console.log("\nVetor de 10000")

  // Vetor Aleatório
  console.log("\nVetor Aleatório:");
  console.log("Bubble Sort:", tempoBubbleSortAleatorio3, "ms");
  console.log("Seleção direta:", tempoSelectionSortAleatorio3, "ms");
  console.log("Inserção direta:", tempoInsertionSortAleatorio3, "ms");
  console.log("Quicksort:", tempoQuicksortAleatorio3, "ms");

  // Vetor Ordenado
  console.log("\nVetor Ordenado:");
  console.log("Bubble Sort:", tempoBubbleSortOrdenado3, "ms");
  console.log("Seleção Direta:", tempoSelectionSortOrdenado3, "ms");
  console.log("Inserção Direta:", tempoInsertionSortOrdenado3, "ms");
  console.log("Quicksort:", tempoQuicksortOrdenado3, "ms");

  // Vetor Invertido
  console.log("\nVetor Invertido:");
  console.log("Bubble Sort:", tempoBubbleSortInvertido3, "ms");
  console.log("Seleção Direta:", tempoSelectionSortInvertido3, "ms");
  console.log("Inserção direta:", tempoInsertionSortInvertido3, "ms");
  console.log("Quicksort:", tempoQuicksortInvertido3, "ms");
 
  // Com 100000
  console.log("\nVetor de 100000")

  // Vetor Aleatório
  console.log("\nVetor Aleatório:");
  console.log("Bubble Sort:", tempoBubbleSortAleatorio4, "ms");
  console.log("Seleção direta:", tempoSelectionSortAleatorio4, "ms");
  console.log("Inserção direta:", tempoInsertionSortAleatorio4, "ms");
  console.log("Quicksort:", tempoQuicksortAleatorio4, "ms");

  // Vetor Ordenado
  console.log("\nVetor Ordenado:");
  console.log("Bubble Sort:", tempoBubbleSortOrdenado4, "ms");
  console.log("Seleção Direta:", tempoSelectionSortOrdenado4, "ms");
  console.log("Inserção Direta:", tempoInsertionSortOrdenado4, "ms");
  console.log("Quicksort:", tempoQuicksortOrdenado4, "ms");

  // Vetor Invertido
  console.log("\nVetor Invertido:");
  console.log("Bubble Sort:", tempoBubbleSortInvertido4, "ms");
  console.log("Seleção Direta:", tempoSelectionSortInvertido4, "ms");
  console.log("Inserção direta:", tempoInsertionSortInvertido4, "ms");
  console.log("Quicksort:", tempoQuicksortInvertido4, "ms");
}
main()