function exe2(){

}

function ins_element(){
    let elementos = []; qtde_elementos
    prompt
}